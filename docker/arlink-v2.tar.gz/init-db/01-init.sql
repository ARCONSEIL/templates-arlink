-- ARLink V2 Database Initialization
-- This script runs when the PostgreSQL container is first created

-- Create extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Note: Tables are created automatically by TypeORM synchronize
-- This file is for any additional initialization needed

-- Create indexes for better performance (will be created after TypeORM creates tables)
-- These are just placeholders - TypeORM will handle the actual table creation
