/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        gold: {
          DEFAULT: '#C9A961',
          light: '#D4B978',
          dark: '#B89A52',
        },
        dark: {
          DEFAULT: '#0a0a0a',
          light: '#1a1a1a',
          medium: '#2a2a2a',
        },
        cream: '#E8E3D5',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Playfair Display', 'serif'],
      },
    },
  },
  plugins: [],
}
