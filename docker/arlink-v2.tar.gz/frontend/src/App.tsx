import { Routes, Route } from 'react-router-dom'
import HomePage from './pages/HomePage'
import GaleriePage from './pages/GaleriePage'
import BoutiquePage from './pages/BoutiquePage'
import DashboardPage from './pages/DashboardPage'
import LoginPage from './pages/LoginPage'
import RegisterPage from './pages/RegisterPage'

function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/galerie" element={<GaleriePage />} />
      <Route path="/galerie/:categorie" element={<GaleriePage />} />
      <Route path="/boutique/:id" element={<BoutiquePage />} />
      <Route path="/dashboard" element={<DashboardPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
    </Routes>
  )
}

export default App
