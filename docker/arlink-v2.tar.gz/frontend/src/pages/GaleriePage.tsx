import { useState, useEffect } from 'react'
import { Link, useParams } from 'react-router-dom'
import { Search, Filter, Grid, List, ArrowLeft } from 'lucide-react'
import { boutiquesService, categoriesService } from '../services/api'

interface Boutique {
  id: string
  societe: string
  description?: string
  ville: string
  pays: string
  categorie: string
  logo?: string
  image?: string
  subDomain?: string
  vues?: number
}

interface Category {
  id: string
  nom: string
  slug: string
  emoji: string
}

export default function GaleriePage() {
  const { categorie } = useParams()
  const [boutiques, setBoutiques] = useState<Boutique[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [selectedCategorie, setSelectedCategorie] = useState(categorie || '')
  const [searchQuery, setSearchQuery] = useState('')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadCategories()
  }, [])

  useEffect(() => {
    loadBoutiques()
  }, [selectedCategorie])

  useEffect(() => {
    if (categorie) {
      setSelectedCategorie(categorie)
    }
  }, [categorie])

  const loadCategories = async () => {
    try {
      const response = await categoriesService.getAll()
      setCategories(response.data)
    } catch (error) {
      console.error('Error loading categories:', error)
    }
  }

  const loadBoutiques = async () => {
    setIsLoading(true)
    try {
      let response
      if (selectedCategorie) {
        response = await boutiquesService.getByCategorie(selectedCategorie)
      } else {
        response = await boutiquesService.getAll({ status: 'active' })
      }
      setBoutiques(response.data)
    } catch (error) {
      console.error('Error loading boutiques:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const filteredBoutiques = boutiques.filter((b) =>
    b.societe.toLowerCase().includes(searchQuery.toLowerCase()) ||
    b.ville?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    b.pays?.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const currentCategory = categories.find((c) => c.slug === selectedCategorie)

  return (
    <div className="min-h-screen bg-dark">
      {/* Header */}
      <header className="bg-dark-light border-b border-dark-medium px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/" className="flex items-center gap-2 text-cream hover:text-gold transition">
              <ArrowLeft className="w-5 h-5" />
              <span className="text-gold text-2xl font-display font-bold">ARLink</span>
            </Link>
          </div>
          <div className="flex-1 max-w-xl mx-8">
            <div className="relative">
              <input
                type="text"
                placeholder="Rechercher une boutique..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-dark border border-dark-medium rounded-lg px-4 py-2 pl-10 text-cream placeholder-gray-500 focus:border-gold focus:outline-none"
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded ${viewMode === 'grid' ? 'bg-gold text-dark' : 'text-cream hover:text-gold'}`}
            >
              <Grid className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded ${viewMode === 'list' ? 'bg-gold text-dark' : 'text-cream hover:text-gold'}`}
            >
              <List className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar - Categories */}
        <aside className="w-64 bg-dark-light border-r border-dark-medium p-4 min-h-screen">
          <h3 className="text-gold font-display text-lg mb-4 flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Catégories
          </h3>
          <ul className="space-y-2">
            <li>
              <button
                onClick={() => setSelectedCategorie('')}
                className={`w-full text-left px-3 py-2 rounded transition ${
                  !selectedCategorie ? 'bg-gold text-dark' : 'text-cream hover:bg-dark-medium'
                }`}
              >
                Toutes les catégories
              </button>
            </li>
            {categories.map((cat) => (
              <li key={cat.id}>
                <button
                  onClick={() => setSelectedCategorie(cat.slug)}
                  className={`w-full text-left px-3 py-2 rounded transition flex items-center gap-2 ${
                    selectedCategorie === cat.slug ? 'bg-gold text-dark' : 'text-cream hover:bg-dark-medium'
                  }`}
                >
                  <span>{cat.emoji}</span>
                  <span>{cat.nom}</span>
                </button>
              </li>
            ))}
          </ul>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          <div className="mb-6">
            <h1 className="text-gold font-display text-2xl">
              {currentCategory ? (
                <>
                  <span className="mr-2">{currentCategory.emoji}</span>
                  {currentCategory.nom}
                </>
              ) : (
                'Toutes les Boutiques'
              )}
            </h1>
            <p className="text-gray-400 mt-1">
              {filteredBoutiques.length} boutique{filteredBoutiques.length > 1 ? 's' : ''} trouvée{filteredBoutiques.length > 1 ? 's' : ''}
            </p>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gold"></div>
            </div>
          ) : viewMode === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredBoutiques.map((boutique) => (
                <Link
                  key={boutique.id}
                  to={`/boutique/${boutique.id}`}
                  className="card overflow-hidden group"
                >
                  <div className="h-40 bg-dark-medium flex items-center justify-center">
                    {boutique.image ? (
                      <img
                        src={boutique.image}
                        alt={boutique.societe}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <span className="text-6xl">🏪</span>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="text-cream font-medium text-lg group-hover:text-gold transition truncate">
                      {boutique.societe}
                    </h3>
                    <p className="text-gray-400 text-sm mt-1">
                      {boutique.ville}, {boutique.pays}
                    </p>
                    {boutique.description && (
                      <p className="text-gray-500 text-sm mt-2 line-clamp-2">
                        {boutique.description}
                      </p>
                    )}
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredBoutiques.map((boutique) => (
                <Link
                  key={boutique.id}
                  to={`/boutique/${boutique.id}`}
                  className="card flex overflow-hidden group"
                >
                  <div className="w-48 h-32 bg-dark-medium flex items-center justify-center flex-shrink-0">
                    {boutique.image ? (
                      <img
                        src={boutique.image}
                        alt={boutique.societe}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <span className="text-4xl">🏪</span>
                    )}
                  </div>
                  <div className="p-4 flex-1">
                    <h3 className="text-cream font-medium text-lg group-hover:text-gold transition">
                      {boutique.societe}
                    </h3>
                    <p className="text-gray-400 text-sm mt-1">
                      {boutique.ville}, {boutique.pays}
                    </p>
                    {boutique.description && (
                      <p className="text-gray-500 text-sm mt-2 line-clamp-2">
                        {boutique.description}
                      </p>
                    )}
                  </div>
                </Link>
              ))}
            </div>
          )}

          {filteredBoutiques.length === 0 && !isLoading && (
            <div className="text-center py-12">
              <span className="text-6xl mb-4 block">🔍</span>
              <h3 className="text-cream text-xl mb-2">Aucune boutique trouvée</h3>
              <p className="text-gray-400">
                Essayez de modifier vos critères de recherche
              </p>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}
