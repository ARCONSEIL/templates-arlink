import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet'
import { ChevronLeft, ChevronRight, Search, User, Menu } from 'lucide-react'
import { boutiquesService, categoriesService } from '../services/api'
import { useAuthStore } from '../stores/authStore'
import L from 'leaflet'

const CATEGORIES = [
  { nom: 'Bijoux', slug: 'bijoux', emoji: '💍' },
  { nom: 'Céramique', slug: 'ceramique', emoji: '🏺' },
  { nom: 'Textile', slug: 'textile', emoji: '🧵' },
  { nom: 'Bois', slug: 'bois', emoji: '🪵' },
  { nom: 'Cuir', slug: 'cuir', emoji: '👜' },
  { nom: 'Métal', slug: 'metal', emoji: '⚒️' },
  { nom: 'Verre', slug: 'verre', emoji: '🥃' },
  { nom: 'Papier', slug: 'papier', emoji: '📜' },
  { nom: 'Pierre', slug: 'pierre', emoji: '💎' },
  { nom: 'Vannerie', slug: 'vannerie', emoji: '🧺' },
  { nom: 'Poterie', slug: 'poterie', emoji: '🫖' },
  { nom: 'Broderie', slug: 'broderie', emoji: '🪡' },
  { nom: 'Tapisserie', slug: 'tapisserie', emoji: '🖼️' },
  { nom: 'Sculpture', slug: 'sculpture', emoji: '🗿' },
  { nom: 'Peinture', slug: 'peinture', emoji: '🎨' },
  { nom: 'Cosmétiques', slug: 'cosmetiques', emoji: '🧴' },
  { nom: 'Épices', slug: 'epices', emoji: '🌶️' },
  { nom: 'Alimentation', slug: 'alimentation', emoji: '🍯' },
  { nom: 'Musique', slug: 'musique', emoji: '🎸' },
  { nom: 'Décoration', slug: 'decoration', emoji: '🏠' },
]

interface MapBoutique {
  id: string
  societe: string
  ville: string
  pays: string
  latitude: number
  longitude: number
  categorie: string
  logo?: string
  image?: string
  subDomain?: string
}

const goldIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-gold.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
})

export default function HomePage() {
  const [mapBoutiques, setMapBoutiques] = useState<MapBoutique[]>([])
  const [categories, setCategories] = useState(CATEGORIES)
  const [carouselIndex, setCarouselIndex] = useState(0)
  const [searchQuery, setSearchQuery] = useState('')
  const [showLoginSidebar, setShowLoginSidebar] = useState(false)
  const { user, logout } = useAuthStore()

  useEffect(() => {
    loadMapData()
    loadCategories()
  }, [])

  const loadMapData = async () => {
    try {
      const response = await boutiquesService.getMapData()
      setMapBoutiques(response.data)
    } catch (error) {
      console.error('Error loading map data:', error)
    }
  }

  const loadCategories = async () => {
    try {
      const response = await categoriesService.getAll()
      if (response.data.length > 0) {
        setCategories(response.data)
      }
    } catch (error) {
      console.error('Error loading categories:', error)
    }
  }

  const nextSlide = () => {
    setCarouselIndex((prev) => (prev + 1) % Math.ceil(categories.length / 5))
  }

  const prevSlide = () => {
    setCarouselIndex((prev) => (prev - 1 + Math.ceil(categories.length / 5)) % Math.ceil(categories.length / 5))
  }

  const visibleCategories = categories.slice(carouselIndex * 5, carouselIndex * 5 + 5)

  return (
    <div className="min-h-screen bg-dark flex flex-col">
      {/* Header */}
      <header className="bg-dark-light border-b border-dark-medium px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/" className="flex items-center gap-2">
              <span className="text-gold text-2xl font-display font-bold">ARLink</span>
              <span className="text-cream text-sm hidden md:block">L'Exposition Mondiale de l'Artisanat</span>
            </Link>
          </div>

          <div className="flex-1 max-w-xl mx-8">
            <div className="relative">
              <input
                type="text"
                placeholder="Rechercher un artisan, une boutique..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-dark border border-dark-medium rounded-lg px-4 py-2 pl-10 text-cream placeholder-gray-500 focus:border-gold focus:outline-none"
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
            </div>
          </div>

          <div className="flex items-center gap-4">
            {user ? (
              <div className="flex items-center gap-4">
                <Link to="/dashboard" className="text-cream hover:text-gold transition">
                  Dashboard
                </Link>
                <button onClick={logout} className="text-cream hover:text-gold transition">
                  Déconnexion
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowLoginSidebar(true)}
                className="flex items-center gap-2 text-cream hover:text-gold transition"
              >
                <User className="w-5 h-5" />
                <span className="hidden md:block">Connexion</span>
              </button>
            )}
            <button className="md:hidden text-cream">
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content - 60% Carousel / 40% Map */}
      <main className="flex-1 flex flex-col lg:flex-row" style={{ height: '400px' }}>
        {/* Carousel Section - 60% */}
        <section className="lg:w-3/5 bg-dark p-6 flex flex-col">
          <h2 className="text-gold font-display text-xl mb-4">Explorez par Catégorie</h2>
          
          <div className="flex-1 relative">
            <button
              onClick={prevSlide}
              className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-dark-light/80 hover:bg-gold text-cream hover:text-dark p-2 rounded-full transition"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            <div className="flex gap-4 justify-center items-center h-full px-12">
              {visibleCategories.map((cat) => (
                <Link
                  key={cat.slug}
                  to={`/galerie/${cat.slug}`}
                  className="card p-6 text-center hover:border-gold transition flex-1 max-w-[180px]"
                >
                  <span className="text-4xl mb-3 block">{cat.emoji}</span>
                  <span className="text-cream font-medium">{cat.nom}</span>
                </Link>
              ))}
            </div>

            <button
              onClick={nextSlide}
              className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-dark-light/80 hover:bg-gold text-cream hover:text-dark p-2 rounded-full transition"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>

          <div className="flex justify-center gap-2 mt-4">
            {Array.from({ length: Math.ceil(categories.length / 5) }).map((_, i) => (
              <button
                key={i}
                onClick={() => setCarouselIndex(i)}
                className={`w-2 h-2 rounded-full transition ${
                  i === carouselIndex ? 'bg-gold' : 'bg-dark-medium'
                }`}
              />
            ))}
          </div>
        </section>

        {/* Map Section - 40% */}
        <section className="lg:w-2/5 bg-dark-light p-4">
          <MapContainer
            center={[20, 0]}
            zoom={2}
            style={{ height: '100%', width: '100%', borderRadius: '0.5rem' }}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            {mapBoutiques.map((boutique) => (
              <Marker
                key={boutique.id}
                position={[boutique.latitude, boutique.longitude]}
                icon={goldIcon}
              >
                <Popup>
                  <div className="text-center">
                    <strong>{boutique.societe}</strong>
                    <br />
                    <span>{boutique.ville}, {boutique.pays}</span>
                    <br />
                    <Link
                      to={`/boutique/${boutique.id}`}
                      className="text-gold hover:underline"
                    >
                      Voir la boutique
                    </Link>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </section>
      </main>

      {/* Featured Boutiques */}
      <section className="bg-dark-light p-6 border-t border-dark-medium">
        <h2 className="text-gold font-display text-xl mb-4">Boutiques en Vedette</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {mapBoutiques.slice(0, 6).map((boutique) => (
            <Link
              key={boutique.id}
              to={`/boutique/${boutique.id}`}
              className="card p-4 text-center"
            >
              <div className="w-16 h-16 mx-auto mb-2 bg-dark-medium rounded-full flex items-center justify-center">
                <span className="text-2xl">🏪</span>
              </div>
              <h3 className="text-cream font-medium text-sm truncate">{boutique.societe}</h3>
              <p className="text-gray-500 text-xs">{boutique.ville}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-dark border-t border-dark-medium px-6 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-gold font-display text-lg mb-4">ARLink</h3>
            <p className="text-gray-400 text-sm">
              L'Exposition Mondiale de l'Artisanat. Découvrez des artisans du monde entier.
            </p>
          </div>
          <div>
            <h4 className="text-cream font-medium mb-4">Navigation</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li><Link to="/galerie" className="hover:text-gold">Galerie</Link></li>
              <li><Link to="/categories" className="hover:text-gold">Catégories</Link></li>
              <li><Link to="/artisans" className="hover:text-gold">Artisans</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-cream font-medium mb-4">Artisans</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li><Link to="/register" className="hover:text-gold">Créer ma boutique</Link></li>
              <li><Link to="/dashboard" className="hover:text-gold">Mon espace</Link></li>
              <li><Link to="/tarifs" className="hover:text-gold">Tarifs</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-cream font-medium mb-4">Contact</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li>contact@arlink.online</li>
              <li>+33 1 23 45 67 89</li>
            </ul>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-dark-medium text-center text-gray-500 text-sm">
          © 2026 ARLink. Tous droits réservés.
        </div>
      </footer>

      {/* Login Sidebar */}
      {showLoginSidebar && (
        <div className="fixed inset-0 z-50 flex">
          <div
            className="flex-1 bg-black/50"
            onClick={() => setShowLoginSidebar(false)}
          />
          <div className="w-full max-w-md bg-dark-light p-8 overflow-y-auto">
            <button
              onClick={() => setShowLoginSidebar(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-cream"
            >
              ✕
            </button>
            <h2 className="text-gold font-display text-2xl mb-6">Connexion</h2>
            <form className="space-y-4">
              <div>
                <label className="block text-cream text-sm mb-2">Email</label>
                <input
                  type="email"
                  className="w-full bg-dark border border-dark-medium rounded-lg px-4 py-2 text-cream focus:border-gold focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-cream text-sm mb-2">Mot de passe</label>
                <input
                  type="password"
                  className="w-full bg-dark border border-dark-medium rounded-lg px-4 py-2 text-cream focus:border-gold focus:outline-none"
                />
              </div>
              <button type="submit" className="btn-gold w-full">
                Se connecter
              </button>
            </form>
            <div className="mt-6 text-center">
              <p className="text-gray-400 text-sm">
                Pas encore de compte ?{' '}
                <Link to="/register" className="text-gold hover:underline">
                  S'inscrire
                </Link>
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
