import { useState, useEffect } from 'react'
import { Link, useParams } from 'react-router-dom'
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet'
import { ArrowLeft, MapPin, Phone, Globe, Facebook, Instagram, Youtube, Share2, Heart, ShoppingCart } from 'lucide-react'
import { boutiquesService, productsService } from '../services/api'
import L from 'leaflet'

interface Boutique {
  id: string
  societe: string
  description?: string
  ville: string
  pays: string
  adresse?: string
  categorie: string
  latitude?: number
  longitude?: number
  logo?: string
  banniere?: string
  image?: string
  subDomain?: string
  vues?: number
  visites?: number
  reseauxSociaux?: {
    facebook?: string
    instagram?: string
    youtube?: string
    tiktok?: string
    linkedin?: string
  }
  artisan?: {
    id: string
    societe: string
    telephone?: string
    whatsapp?: string
    siteWeb?: string
  }
}

interface Product {
  id: string
  nom: string
  titre?: string
  description?: string
  prix: number
  prixGros?: number
  img1?: string
  img2?: string
  img3?: string
  stock: number
  vedette: boolean
}

const goldIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-gold.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
})

export default function BoutiquePage() {
  const { id } = useParams()
  const [boutique, setBoutique] = useState<Boutique | null>(null)
  const [products, setProducts] = useState<Product[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)

  useEffect(() => {
    if (id) {
      loadBoutique()
      loadProducts()
    }
  }, [id])

  const loadBoutique = async () => {
    try {
      const response = await boutiquesService.getById(id!)
      setBoutique(response.data)
    } catch (error) {
      console.error('Error loading boutique:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const loadProducts = async () => {
    try {
      const response = await productsService.getByBoutique(id!)
      setProducts(response.data)
    } catch (error) {
      console.error('Error loading products:', error)
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-dark flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gold"></div>
      </div>
    )
  }

  if (!boutique) {
    return (
      <div className="min-h-screen bg-dark flex items-center justify-center">
        <div className="text-center">
          <span className="text-6xl mb-4 block">🔍</span>
          <h2 className="text-cream text-xl mb-2">Boutique non trouvée</h2>
          <Link to="/galerie" className="text-gold hover:underline">
            Retour à la galerie
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-dark">
      {/* Header */}
      <header className="bg-dark-light border-b border-dark-medium px-6 py-4">
        <div className="flex items-center justify-between">
          <Link to="/galerie" className="flex items-center gap-2 text-cream hover:text-gold transition">
            <ArrowLeft className="w-5 h-5" />
            <span>Retour à la galerie</span>
          </Link>
          <div className="flex items-center gap-4">
            <button className="flex items-center gap-2 text-cream hover:text-gold transition">
              <Heart className="w-5 h-5" />
              <span className="hidden md:block">Favoris</span>
            </button>
            <button className="flex items-center gap-2 text-cream hover:text-gold transition">
              <Share2 className="w-5 h-5" />
              <span className="hidden md:block">Partager</span>
            </button>
          </div>
        </div>
      </header>

      {/* Banner */}
      <div className="h-64 bg-dark-medium relative">
        {boutique.banniere ? (
          <img
            src={boutique.banniere}
            alt={boutique.societe}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-r from-dark-light to-dark-medium flex items-center justify-center">
            <span className="text-8xl opacity-20">🏪</span>
          </div>
        )}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-dark to-transparent h-32" />
      </div>

      {/* Boutique Info */}
      <div className="max-w-7xl mx-auto px-6 -mt-16 relative z-10">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Logo */}
          <div className="w-32 h-32 bg-dark-light border-4 border-gold rounded-xl flex items-center justify-center flex-shrink-0">
            {boutique.logo ? (
              <img
                src={boutique.logo}
                alt={boutique.societe}
                className="w-full h-full object-cover rounded-lg"
              />
            ) : (
              <span className="text-5xl">🏪</span>
            )}
          </div>

          {/* Info */}
          <div className="flex-1">
            <h1 className="text-gold font-display text-3xl mb-2">{boutique.societe}</h1>
            <div className="flex items-center gap-4 text-gray-400 mb-4">
              <span className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                {boutique.ville}, {boutique.pays}
              </span>
              <span className="text-gold">{boutique.categorie}</span>
            </div>
            {boutique.description && (
              <p className="text-cream mb-4">{boutique.description}</p>
            )}

            {/* Social Links */}
            <div className="flex items-center gap-4">
              {boutique.reseauxSociaux?.facebook && (
                <a href={boutique.reseauxSociaux.facebook} target="_blank" rel="noopener noreferrer" className="text-cream hover:text-gold transition">
                  <Facebook className="w-5 h-5" />
                </a>
              )}
              {boutique.reseauxSociaux?.instagram && (
                <a href={boutique.reseauxSociaux.instagram} target="_blank" rel="noopener noreferrer" className="text-cream hover:text-gold transition">
                  <Instagram className="w-5 h-5" />
                </a>
              )}
              {boutique.reseauxSociaux?.youtube && (
                <a href={boutique.reseauxSociaux.youtube} target="_blank" rel="noopener noreferrer" className="text-cream hover:text-gold transition">
                  <Youtube className="w-5 h-5" />
                </a>
              )}
              {boutique.artisan?.siteWeb && (
                <a href={boutique.artisan.siteWeb} target="_blank" rel="noopener noreferrer" className="text-cream hover:text-gold transition">
                  <Globe className="w-5 h-5" />
                </a>
              )}
              {boutique.artisan?.telephone && (
                <a href={`tel:${boutique.artisan.telephone}`} className="text-cream hover:text-gold transition">
                  <Phone className="w-5 h-5" />
                </a>
              )}
            </div>
          </div>

          {/* Stats */}
          <div className="flex flex-col gap-2 text-right">
            <div className="text-gray-400 text-sm">
              <span className="text-gold font-bold">{boutique.vues || 0}</span> vues
            </div>
            <div className="text-gray-400 text-sm">
              <span className="text-gold font-bold">{boutique.visites || 0}</span> visites
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Products */}
          <div className="lg:col-span-2">
            <h2 className="text-gold font-display text-xl mb-6">Produits ({products.length})</h2>
            {products.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {products.map((product) => (
                  <div
                    key={product.id}
                    className="card overflow-hidden cursor-pointer"
                    onClick={() => setSelectedProduct(product)}
                  >
                    <div className="h-48 bg-dark-medium flex items-center justify-center">
                      {product.img1 ? (
                        <img
                          src={product.img1}
                          alt={product.nom}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span className="text-6xl">📦</span>
                      )}
                    </div>
                    <div className="p-4">
                      <h3 className="text-cream font-medium text-lg truncate">{product.nom}</h3>
                      {product.titre && (
                        <p className="text-gray-400 text-sm truncate">{product.titre}</p>
                      )}
                      <div className="flex items-center justify-between mt-4">
                        <span className="text-gold font-bold text-xl">{product.prix} €</span>
                        <button className="btn-gold flex items-center gap-2 text-sm py-2 px-4">
                          <ShoppingCart className="w-4 h-4" />
                          Ajouter
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-dark-light rounded-xl">
                <span className="text-6xl mb-4 block">📦</span>
                <h3 className="text-cream text-xl mb-2">Aucun produit</h3>
                <p className="text-gray-400">Cette boutique n'a pas encore ajouté de produits</p>
              </div>
            )}
          </div>

          {/* Sidebar - Map & Contact */}
          <div className="space-y-6">
            {/* Map */}
            {boutique.latitude && boutique.longitude && (
              <div className="card p-4">
                <h3 className="text-gold font-display text-lg mb-4">Localisation</h3>
                <div className="h-64 rounded-lg overflow-hidden">
                  <MapContainer
                    center={[boutique.latitude, boutique.longitude]}
                    zoom={13}
                    style={{ height: '100%', width: '100%' }}
                  >
                    <TileLayer
                      attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    <Marker position={[boutique.latitude, boutique.longitude]} icon={goldIcon}>
                      <Popup>{boutique.societe}</Popup>
                    </Marker>
                  </MapContainer>
                </div>
                {boutique.adresse && (
                  <p className="text-gray-400 text-sm mt-4">
                    <MapPin className="w-4 h-4 inline mr-1" />
                    {boutique.adresse}
                  </p>
                )}
              </div>
            )}

            {/* Contact */}
            <div className="card p-4">
              <h3 className="text-gold font-display text-lg mb-4">Contact</h3>
              <div className="space-y-3">
                {boutique.artisan?.telephone && (
                  <a
                    href={`tel:${boutique.artisan.telephone}`}
                    className="flex items-center gap-3 text-cream hover:text-gold transition"
                  >
                    <Phone className="w-5 h-5" />
                    <span>{boutique.artisan.telephone}</span>
                  </a>
                )}
                {boutique.artisan?.siteWeb && (
                  <a
                    href={boutique.artisan.siteWeb}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 text-cream hover:text-gold transition"
                  >
                    <Globe className="w-5 h-5" />
                    <span>Site web</span>
                  </a>
                )}
              </div>
              <button className="btn-gold w-full mt-4">
                Contacter l'artisan
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Product Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/70"
            onClick={() => setSelectedProduct(null)}
          />
          <div className="relative bg-dark-light rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setSelectedProduct(null)}
              className="absolute top-4 right-4 text-gray-400 hover:text-cream z-10"
            >
              ✕
            </button>
            <div className="h-64 bg-dark-medium">
              {selectedProduct.img1 ? (
                <img
                  src={selectedProduct.img1}
                  alt={selectedProduct.nom}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <span className="text-8xl">📦</span>
                </div>
              )}
            </div>
            <div className="p-6">
              <h2 className="text-gold font-display text-2xl mb-2">{selectedProduct.nom}</h2>
              {selectedProduct.titre && (
                <p className="text-cream text-lg mb-4">{selectedProduct.titre}</p>
              )}
              {selectedProduct.description && (
                <p className="text-gray-400 mb-6">{selectedProduct.description}</p>
              )}
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-gold font-bold text-3xl">{selectedProduct.prix} €</span>
                  {selectedProduct.prixGros && (
                    <span className="text-gray-400 text-sm ml-2">
                      (Gros: {selectedProduct.prixGros} €)
                    </span>
                  )}
                </div>
                <button className="btn-gold flex items-center gap-2">
                  <ShoppingCart className="w-5 h-5" />
                  Ajouter au panier
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
